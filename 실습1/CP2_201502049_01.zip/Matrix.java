
public class Matrix {

	private int row;
	private int col;
	private int Index;
	private double[][] matrix;

	public Matrix(int row, int col) {
		matrix = new double[row][col];
		this.row = row;
		this.col = col;
	}

	public void setMatrix(double... d) {
		for (int i = 0; i < d.length; i++)
			matrix[Index][i] = d[i];
		Index++;
	}

	public Matrix addMatrix(Matrix otherMatrix) {
		Matrix a = this;
		Matrix b = new Matrix(row, col);
		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				b.matrix[i][j] = a.matrix[i][j] + otherMatrix.matrix[i][j];
		return b;

	}

	public Matrix multiMatrix(Matrix otherMatrix) {
		Matrix a = this;
		Matrix c = new Matrix(a.row, otherMatrix.col);
		for (int i = 0; i < c.row; i++)
			for (int j = 0; j < c.col; j++)
				for (int k = 0; k < a.col; k++)
					c.matrix[i][j] = c.matrix[i][j] + (a.matrix[i][k] * otherMatrix.matrix[k][j]);
		return c;
	}

	public Matrix transposed() {
		Matrix a = new Matrix(col, row);
		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				a.matrix[j][i] = this.matrix[i][j];

		return a;
	}

	public void print() {
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++)
				System.out.print("[" + matrix[i][j] + "]");
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Matrix mat1 = new Matrix(3, 2);
		mat1.setMatrix(1, -2);
		mat1.setMatrix(3, 4);
		mat1.setMatrix(5, 6);
		Matrix mat2 = new Matrix(2, 3);
		mat2.setMatrix(1, 2, 3);
		mat2.setMatrix(4, 5, 6);

		System.out.println("ù��° ���");
		mat1.print();
		System.out.println();
		System.out.println("�ι�° ���");
		mat2.print();
		System.out.println();
		System.out.println("�� ����� ����");
		mat1.multiMatrix(mat2).print();
		System.out.println();
		System.out.println("ù��° ��� + ù���� ���");
		mat1.addMatrix(mat1).print();

		System.out.println();
		System.out.println("�ι�° ����� ��ġ���");
		mat2.transposed().print();
	}

}

